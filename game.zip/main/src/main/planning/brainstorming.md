- Staircase with puzzles -> Level on top of tower -> Level in throne room -> dungeon -> treasure room -> end of game

1. Staircase
    - objects and enemies that roll down the stairs and you have to dodge
    - blockades that can only be passed by solving puzzles
    - objects are thrown by weird magician
    - -> player enters throne room

2. Throne room
    -  