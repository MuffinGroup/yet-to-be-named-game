import json

with open("src\main/assets\lang/test.json", "r") as f:
    data = json.load(f)